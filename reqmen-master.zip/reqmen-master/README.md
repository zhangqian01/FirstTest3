# reqmen接口测试平台

python3.6+、 flask、sqlalchemy、request、pymysql


新版接口测试平台、持续优化开发中、

测试套件详情、设计中、


![首页](https://github.com/Esaxiya/reqmen/blob/master/image/%E9%A6%96%E9%A1%B5.png)<br>
![项目管理](https://github.com/Esaxiya/reqmen/blob/master/image/%E9%A1%B9%E7%9B%AE%E7%AE%A1%E7%90%86.png)<br>
![项目新增](https://github.com/Esaxiya/reqmen/blob/master/image/%E9%A1%B9%E7%9B%AE%E6%96%B0%E5%A2%9E.png)<br>
![接口管理](https://github.com/Esaxiya/reqmen/blob/master/image/%E6%8E%A5%E5%8F%A3%E7%AE%A1%E7%90%86.png)<br>
![接口新增](https://github.com/Esaxiya/reqmen/blob/master/image/%E6%8E%A5%E5%8F%A3%E6%96%B0%E5%A2%9E.png)<br>
![用例管理](https://github.com/Esaxiya/reqmen/blob/master/image/%E7%94%A8%E4%BE%8B%E7%AE%A1%E7%90%86.png)<br>
![用例新增](https://github.com/Esaxiya/reqmen/blob/master/image/%E7%94%A8%E4%BE%8B%E6%96%B0%E5%A2%9E.png)<br>
![集合管理](https://github.com/Esaxiya/reqmen/blob/master/image/%E7%94%A8%E4%BE%8B%E9%9B%86%E5%90%88.png)<br>
![集合新增](https://github.com/Esaxiya/reqmen/blob/master/image/%E7%94%A8%E4%BE%8B%E9%9B%86%E5%90%88%E7%AE%A1%E7%90%86.png)<br>
![测试环境](https://github.com/Esaxiya/reqmen/blob/master/image/%E6%B5%8B%E8%AF%95%E7%8E%AF%E5%A2%83%E7%AE%A1%E7%90%86.png)<br>
![环境新增](https://github.com/Esaxiya/reqmen/blob/master/image/%E6%B5%8B%E8%AF%95%E7%8E%AF%E5%A2%83.png)<br>
![注册](https://github.com/Esaxiya/reqmen/blob/master/image/register.png)<br>
![登陆](https://github.com/Esaxiya/reqmen/blob/master/image/login.png)<br>
![技术社区](https://github.com/Esaxiya/reqmen/blob/master/image/question.png)<br>
![新增](https://github.com/Esaxiya/reqmen/blob/master/image/add.png)<br>
![详情](https://github.com/Esaxiya/reqmen/blob/master/image/detail.png)<br>
![评论](https://github.com/Esaxiya/reqmen/blob/master/image/comments.png)<br>


#